import json
import os
import re
class Contact:
    def __init__(self,cid,Name,Phone,Email,City,Company):
        self.cid=cid
        self.name=Name
        self.phone=Phone
        self.email=Email
        self.city=City
        self.company=Company
    def to_dict(self):
        return{
            "cid":self.cid
            ,"name":self.name
            ,"phone":self.phone
            ,"email":self.email
            ,"city":self.city
            ,"company":self.company
        }
class CRMsystem:
    def __init__(self,filename="Contacts.json"):
        self.filename = filename
        self.contact = self.load_data()
    def load_data(self):
        if os.path.exists(self.filename):
            try:
                with open(self.filename,'r')as f:
                    data = json.load(f)
                    return [Contact(c["cid"], c["name"], c["phone"], c["email"], c["city"], c["company"]) for c in data]
            except (json.JSONDecodeError,TypeError):
                print("Warning : Data Not Found,  Starting with empty list")
                return []
        return []
    def save_data(self):
        try:
            with open(self.filename,'w') as f:
                json.dump([c.to_dict() for c in self.contact], f, indent=8)
        except IOError as e:
            print(f"Error to save data : {e}")
    def validate_email(self,email):
        if "@" in email and "." in email:
            return True
        return False
    def display_table(self,contact_list):
        if not contact_list:
            print("Not found")
            return
        
        for c in contact_list:
            print(f"{c.cid} / [\{c.name} / {c.phone} / {c.email} / {c.city} / {c.company}]")
        
    def add_contact(self):
        Name = input("Enter Name : ").strip()
        Phone = input("Enter Phone : ").strip()
        Email = input("Enter Email : ").strip()
        City = input("Enter City : ").strip()
        Company = input("Enter Company : ").strip()
        cid = len(self.contact) + 1
        new_contact = Contact(cid,Name,Phone,Email,City,Company)
        self.contact.append(new_contact)
        self.save_data()
        print("Contact added successfully.")
        if not Name or not self.validate_email(Email):
            print("Invalid Name or Email format.")
            return
        new_id = max([c.cid for c in self.contact], default=0) + 1
        new_person = Contact(new_id, Name, Phone, Email, City, Company)
        self.contact.append(new_person)
        self.save_data()
        print(f"Contact '{Name}' Saved Sucessfullly")
    def search_contact(self):
        query = input("Enter the Name phone or email You want to search : ").lower().strip()
        results = [c for c in self.contact if query in c.name.lower() or query in c.phone or query in c.email.lower()]
        self.display_table(results)
    def filter_contacts(self):
        filter = input("Enter the city or Company to filtter : ").lower().strip()
        choice = int(input("1 for City and 2 for Compay : " ))
        if choice == 1:
                result = [c for c in self.contact if filter in c.city.lower()]
        elif choice == 2:
            result = [c for c in self.contact if filter in c.company.lower()]
        else:
            print("Invalid Choice : Try Again" \
            "")
            return
        self.display_table(result)
    def update_contact(self):
        try:
            target_id = int(input("Enter the id of Contact you want to update :"))
            for c in self.contact:
                if c.cid == target_id:
                    print(f"Current Name : {c.name}")
                    c.name = input("Enter new Name : " ).strip()
                    c.phone = input("Enter new phone : " ).strip()
                    c.email = input("Enter new email : " ).strip()
                    c.city = input("Enter new city : " ).strip()
                    c.company = input("Enter new company : " ).strip()
                    self.save_data()
                    print("Contact Updated Successfully")
                    return
                print("Contact not found ")
        except ValueError:
                print("Invalid input. Please enter a numeric ID, Try Again.")
    def delete_contact(self):
            try:
                target_id = int(input("Enter the id "))
                for c in self.contact:
                    if c.cid == target_id:
                        self.contact.remove(c)
                        self.save_data()
                        print("Contact Delete Successfully")
                        return
                print("Contact Not found")
            except ValueError:
                print("Invalid input.")
def main_menu():
    crm = CRMsystem()
    while True:
        print("1.Add Contact\n2.Search Contact\n3.Filter Contact\n4.Update Contact\n5.Delete Contact\n6.Exit")
        choice = input("\nSelect an option: ").strip() 
        
        if choice == '1':
            crm.add_contact()
        elif choice == '2':
            crm.search_contact()
        elif choice == '3':
            crm.filter_contacts()
        elif choice == '4':
            crm.update_contact()
        elif choice == '5':
            crm.delete_contact()
        elif choice == '6':
            print("Exiting... Goodbye!")
            break
        else: 
            print("Invalid choice. Please select a valid option.")
if __name__ == "__main__":
    main_menu()