import smtplib
import csv
import json
import os
from datetime import datetime
from email.message import EmailMessage

class EmailEngine:
    def __init__(self):
        self.server = None
        self.sender_email = ""
        self.is_logged_in = False

    def login(self, email, app_password):
        """Establishes a secure connection to Gmail/Outlook SMTP."""
        try:
            # Using Gmail's SMTP server as a standard
            self.server = smtplib.SMTP("smtp.gmail.com", 587)
            self.server.starttls()  # Secure the connection
            self.server.login(email, app_password)
            
            self.sender_email = email
            self.is_logged_in = True
            print(f"✅ Securely logged in as: {email}")
            return True
        except Exception as e:
            print(f"❌ Login Failed: Please check your App Password. Error: {e}")
            return False

    def send_personalized_email(self, recipient_data, subject, template):
        """Replaces placeholders and sends a single email."""
        try:
            # Replacing placeholders like {name} with data from CSV
            personalized_msg = template.format(**recipient_data)

            msg = EmailMessage()
            msg.set_content(personalized_msg)
            msg['Subject'] = subject
            msg['From'] = self.sender_email
            msg['To'] = recipient_data['email']

            self.server.send_message(msg)
            return True, "Sent"
        except Exception as e:
            return False, str(e)

    def logout(self):
        if self.server:
            self.server.quit()


class DataManager:
    @staticmethod
    def load_contacts(file_path):
        """Loads names and emails from a CSV file."""
        contacts = []
        if not os.path.exists(file_path):
            print("⚠️ Contact file not found!")
            return []
            
        with open(file_path, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                contacts.append(row)
        return contacts

    @staticmethod
    def save_history(record):
        """Saves the email status to a JSON history file."""
        history_file = "email_history.json"
        data = []
        
        if os.path.exists(history_file):
            with open(history_file, 'r') as f:
                try:
                    data = json.load(f)
                except: data = []

        data.append(record)
        with open(history_file, 'w') as f:
            json.dump(data, f, indent=4)


# --- HUMANIZED CLI INTERFACE ---
def main():
    engine = EmailEngine()
    manager = DataManager()

    print("--- 📧 HK Bulk Email System ---")
    email = input("Enter your Email: ")
    password = input("Enter your App Password: ")

    if engine.login(email, password):
        while True:
            print("\n1. Send Bulk Emails\n2. View History\n3. Exit")
            choice = input("Action: ")

            if choice == '1':
                csv_file = input("Enter CSV filename (e.g., contacts.csv): ")
                contacts = manager.load_contacts(csv_file)
                
                if not contacts: continue

                subject = input("Subject: ")
                print("\nEnter Template (Use {name} or {company} for personalization):")
                print("Example: Hi {name}, welcome to {company}!")
                template = input("> ")

                for person in contacts:
                    success, status = engine.send_personalized_email(person, subject, template)
                    
                    # Record the result
                    history_entry = {
                        "email": person['email'],
                        "status": status,
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    }
                    manager.save_history(history_entry)
                    print(f"📧 Sending to {person['email']}... {status}")

            elif choice == '3':
                engine.logout()
                break
    
if __name__ == "__main__":
    main()