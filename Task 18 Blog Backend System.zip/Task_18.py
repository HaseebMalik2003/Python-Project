import sqlite3
from datetime import datetime

class BlogSystem:
    def __init__(self):
        self.conn = sqlite3.connect('blog.db')
        self.cursor = self.conn.cursor()
        self.init_tables()

    def init_tables(self):
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS posts 
            (id INTEGER PRIMARY KEY, title TEXT, content TEXT, author TEXT, date TEXT)''')
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS comments 
            (id INTEGER PRIMARY KEY, post_id INTEGER, user TEXT, comment TEXT)''')
        self.conn.commit()

    def create_post(self, title, content, author):
        date = datetime.now().strftime("%Y-%m-%d")
        self.cursor.execute('INSERT INTO posts (title, content, author, date) VALUES (?, ?, ?, ?)',
                           (title, content, author, date))
        self.conn.commit()

    def get_posts(self):
        self.cursor.execute('SELECT * FROM posts')
        return self.cursor.fetchall()

    def add_comment(self, post_id, user, text):
        self.cursor.execute('INSERT INTO comments (post_id, user, comment) VALUES (?, ?, ?)',
                           (post_id, user, text))
        self.conn.commit()

    def get_comments(self, post_id):
        self.cursor.execute('SELECT user, comment FROM comments WHERE post_id = ?', (post_id,))
        return self.cursor.fetchall()

def main():
    blog = BlogSystem()
    while True:
        print("\n--- BLOG BACKEND ---")
        print("1. Create Post\n2. View All Posts\n3. Comment on Post\n4. Exit")
        choice = input("Choice: ")

        if choice == '1':
            t = input("Title: ")
            c = input("Content: ")
            a = input("Author: ")
            blog.create_post(t, c, a)
        elif choice == '2':
            posts = blog.get_posts()
            for p in posts:
                print(f"\nID: {p[0]} | {p[1]} by {p[3]}")
                print(f"Content: {p[2]}")
                comments = blog.get_comments(p[0])
                for com in comments: print(f"  - {com[0]}: {com[1]}")
        elif choice == '3':
            pid = int(input("Post ID: "))
            u = input("Your Name: ")
            msg = input("Comment: ")
            blog.add_comment(pid, u, msg)
        elif choice == '4':
            break

if __name__ == "__main__":
    main()