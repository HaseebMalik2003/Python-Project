import tkinter as tk
from tkinter import messagebox, filedialog
import base64
import json
import os

class EncryptionGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Secure Data Vault")
        self.root.geometry("450x500")
        
        # --- Internal State & OS Pathing ---
        self.shift_key = 5
        # Automatically find the folder where this script is saved
        self.current_dir = os.path.dirname(os.path.abspath(__file__))
        
        # --- UI Elements ---
        tk.Label(root, text="Custom Encryption Tool", font=("Arial", 16, "bold")).pack(pady=10)

        tk.Label(root, text="Enter Text Below:").pack()
        self.text_entry = tk.Text(root, height=8, width=45)
        self.text_entry.pack(pady=5)

        # Encryption/Decryption Buttons
        tk.Button(root, text="Encrypt Data", command=self.handle_encrypt, bg="#d1f2eb", width=25).pack(pady=2)
        tk.Button(root, text="Decrypt Data", command=self.handle_decrypt, bg="#fdedec", width=25).pack(pady=2)
        
        tk.Label(root, text="--- File Storage (JSON & OS) ---").pack(pady=10)
        
        # Save/Load Buttons
        tk.Button(root, text="Save Encrypted to File", command=self.handle_save, width=25).pack(pady=2)
        tk.Button(root, text="Load & Decrypt File", command=self.handle_load, width=25).pack(pady=2)

        # Status Label to show file location
        self.status_label = tk.Label(root, text=f"Work Dir: {os.path.basename(self.current_dir)}", fg="gray")
        self.status_label.pack(side="bottom", pady=10)

    # --- Core Logic: The Custom Caesar Shift ---
    def custom_transform(self, text, decrypt=False):
        """Moves characters based on Unicode values."""
        direction = -1 if decrypt else 1
        result = ""
        for char in text:
            # ord() gets number, chr() turns it back to letter
            result += chr(ord(char) + (self.shift_key * direction))
        return result

    # --- Button Handlers ---
    def handle_encrypt(self):
        raw_text = self.text_entry.get("1.0", tk.END).strip()
        if not raw_text:
            messagebox.showwarning("Warning", "Nothing to encrypt!")
            return
        
        # 1. Custom Logic Shift
        shifted = self.custom_transform(raw_text)
        # 2. Base64 Encoding (makes it unreadable)
        encrypted = base64.b64encode(shifted.encode()).decode()
        
        self.text_entry.delete("1.0", tk.END)
        self.text_entry.insert("1.0", encrypted)
        messagebox.showinfo("Success", "Data Encrypted!")

    def handle_decrypt(self):
        encrypted_text = self.text_entry.get("1.0", tk.END).strip()
        try:
            # 1. Reverse Base64
            decoded_bytes = base64.b64decode(encrypted_text.encode())
            decoded_str = decoded_bytes.decode()
            # 2. Reverse Custom Shift
            original = self.custom_transform(decoded_str, decrypt=True)
            
            self.text_entry.delete("1.0", tk.END)
            self.text_entry.insert("1.0", original)
        except Exception:
            messagebox.showerror("Error", "This text is not valid encrypted data!")

    def handle_save(self):
        data = self.text_entry.get("1.0", tk.END).strip()
        if not data:
            messagebox.showwarning("Error", "No data to save!")
            return

        file_path = filedialog.asksaveasfilename(
            initialdir=self.current_dir,
            defaultextension=".json",
            filetypes=[("JSON files", "*.json")]
        )
        
        if file_path:
            # Wrapping in a dictionary for JSON structure
            payload = {"vault_data": data}
            with open(file_path, "w") as f:
                json.dump(payload, f, indent=4)
            messagebox.showinfo("Saved", f"Encrypted data stored at:\n{os.path.basename(file_path)}")

    def handle_load(self):
        file_path = filedialog.askopenfilename(
            initialdir=self.current_dir,
            filetypes=[("JSON files", "*.json")]
        )
        
        if file_path and os.path.exists(file_path):
            try:
                with open(file_path, "r") as f:
                    content = json.load(f)
                    
                if "vault_data" in content:
                    encrypted_val = content["vault_data"]
                    self.text_entry.delete("1.0", tk.END)
                    self.text_entry.insert("1.0", encrypted_val)
                    # Automatically trigger decryption
                    self.handle_decrypt()
                else:
                    messagebox.showerror("Format Error", "This JSON is not a valid vault file.")
            except Exception as e:
                messagebox.showerror("Load Error", f"Could not read file: {e}")

# --- Execution ---
if __name__ == "__main__":
    root = tk.Tk()
    app = EncryptionGUI(root)
    root.mainloop()