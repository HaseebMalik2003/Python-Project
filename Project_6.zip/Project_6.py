import os
from datetime import datetime
from tkinter import messagebox, filedialog
import tkinter as tk
from tkinter import ttk

# Libraries for PDF generation
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

class PDFEngine:
    def __init__(self, filename):
        self.filename = filename
        self.styles = getSampleStyleSheet()

    def create_report(self, user_info, data_rows):
        """Generates a professional PDF with tables."""
        try:
            # Create folder if it doesn't exist
            os.makedirs("Reports", exist_ok=True)
            path = os.path.join("Reports", self.filename)
            
            doc = SimpleDocTemplate(path, pagesize=letter)
            elements = []

            # 1. Title
            title_style = ParagraphStyle('TitleStyle', parent=self.styles['Heading1'], alignment=1, spaceAfter=20)
            elements.append(Paragraph("OFFICIAL PERFORMANCE REPORT", title_style))

            # 2. Metadata (Date and Time)
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            elements.append(Paragraph(f"Date Generated: {now}", self.styles['Normal']))
            elements.append(Spacer(1, 12))

            # 3. User Details Header
            elements.append(Paragraph(f"<b>Name:</b> {user_info['name']}", self.styles['Normal']))
            elements.append(Paragraph(f"<b>ID:</b> {user_info['id']}", self.styles['Normal']))
            elements.append(Paragraph(f"<b>Dept/Company:</b> {user_info['dept']}", self.styles['Normal']))
            elements.append(Spacer(1, 20))

            # 4. Data Table
            # Table Header + Data
            table_data = [["Category", "Details/Score"]] + data_rows
            
            t = Table(table_data, colWidths=[150, 300])
            t.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            elements.append(t)

            # Build PDF
            doc.build(elements)
            return True, path
        except Exception as e:
            return False, str(e)

class AppGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("HK Academy - PDF Report Generator")
        self.root.geometry("450x550")
        
        self.setup_ui()

    def setup_ui(self):
        # Header
        ttk.Label(self.root, text="Student/Company Report System", font=("Helvetica", 16, "bold")).pack(pady=10)

        # Form Fields
        fields = [("Name:", "name"), ("ID/Roll No:", "id"), ("Email:", "email"), ("Dept/Role:", "dept")]
        self.entries = {}

        for label_text, var_name in fields:
            frame = ttk.Frame(self.root)
            frame.pack(fill="x", padx=20, pady=5)
            ttk.Label(frame, text=label_text, width=15).pack(side="left")
            self.entries[var_name] = ttk.Entry(frame)
            self.entries[var_name].pack(side="right", expand=True, fill="x")

        # Performance Area
        ttk.Label(self.root, text="Performance Details (e.g., Attendance: 90%):").pack(pady=(10, 0))
        self.performance_text = tk.Text(self.root, height=5, width=40)
        self.performance_text.pack(pady=5)

        # Buttons
        ttk.Button(self.root, text="Generate PDF Report", command=self.handle_generation).pack(pady=20)

    def handle_generation(self):
        # 1. Strong Validation (Anti-Empty Logic)
        user_data = {k: v.get().strip() for k, v in self.entries.items()}
        details = self.performance_text.get("1.0", "end").strip()

        if not all(user_data.values()) or not details:
            messagebox.showerror("Error", "All fields are required. Please complete the form.")
            return

        # 2. Prepare Table Data
        # We split the text area into rows for the table
        data_rows = []
        for line in details.split('\n'):
            if ":" in line:
                data_rows.append(line.split(":", 1))
            else:
                data_rows.append(["Info", line])

        # 3. Call PDF Engine
        filename = f"Report_{user_data['id']}_{datetime.now().strftime('%H%M%S')}.pdf"
        engine = PDFEngine(filename)
        success, message = engine.create_report(user_data, data_rows)

        if success:
            messagebox.showinfo("Success", f"Report saved successfully at:\n{message}")
            self.clear_fields()
        else:
            messagebox.showerror("System Error", f"Failed to generate PDF: {message}")

    def clear_fields(self):
        for entry in self.entries.values():
            entry.delete(0, tk.END)
        self.performance_text.delete("1.0", tk.END)

if __name__ == "__main__":
    # Ensure library is installed: pip install reportlab
    root = tk.Tk()
    app = AppGUI(root)
    root.mainloop()