import os
import sys
import csv
import sqlite3
from datetime import datetime

DB_NAME = "attendance.db"
CSV_NAME = "attendance_records.csv"

def get_connection():
    return sqlite3.connect(DB_NAME)

def initialize_db():
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS attendance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                emp_id TEXT NOT NULL,
                name TEXT NOT NULL,
                date TEXT NOT NULL,
                status TEXT NOT NULL,
                UNIQUE(emp_id, date)
            )
        """)
        conn.commit()

def sync_db_to_csv():
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT emp_id, name, date, status 
                FROM attendance 
                ORDER BY date DESC, emp_id ASC
            """)
            records = cursor.fetchall()

        with open(CSV_NAME, mode="w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(["Employee/Student ID", "Name", "Date", "Status"])
            writer.writerows(records)
    except Exception as e:
        print(f"\n⚠️ Sync Error: {e}")

def validate_date(date_str):
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
        return True
    except ValueError:
        return False

def mark_attendance():
    print("\n--- Mark Attendance ---")
    emp_id = input("Enter Student/Employee ID: ").strip().upper()
    if not emp_id:
        print("❌ ID cannot be empty.")
        return

    name = input("Enter Name: ").strip()
    if not name:
        print("❌ Name cannot be empty.")
        return

    date_input = input("Enter Date (YYYY-MM-DD) or press Enter for Today: ").strip()
    if not date_input:
        date_str = datetime.now().strftime("%Y-%m-%d")
    else:
        if not validate_date(date_input):
            print("❌ Invalid date format. Use YYYY-MM-DD.")
            return
        date_str = date_input

    print("Select Status: [1] Present  [2] Absent  [3] Late")
    choice = input("Enter choice (1-3): ").strip()
    status_map = {"1": "Present", "2": "Absent", "3": "Late"}
    status = status_map.get(choice)

    if not status:
        print("❌ Invalid status choice.")
        return

    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO attendance (emp_id, name, date, status) VALUES (?, ?, ?, ?)",
                (emp_id, name, date_str, status)
            )
            conn.commit()
        print(f"✅ Attendance marked for {name} ({emp_id}) on {date_str}!")
        sync_db_to_csv()
    except sqlite3.IntegrityError:
        print(f"❌ Error: Attendance already marked for ID '{emp_id}' on {date_str}.")
    except Exception as e:
        print(f"❌ Database Error: {e}")

def view_records():
    print("\n--- View Records ---")
    print("[1] View by Date\n[2] View by Student/Employee ID\n[3] View All Records")
    choice = input("Enter choice: ").strip()

    query = "SELECT emp_id, name, date, status FROM attendance"
    params = ()

    if choice == "1":
        date_str = input("Enter Date (YYYY-MM-DD): ").strip()
        if not validate_date(date_str):
            print("❌ Invalid date format.")
            return
        query += " WHERE date = ?"
        params = (date_str,)
    elif choice == "2":
        emp_id = input("Enter Student/Employee ID: ").strip().upper()
        query += " WHERE UPPER(emp_id) = ?"
        params = (emp_id,)
    elif choice != "3":
        print("❌ Invalid choice.")
        return

    query += " ORDER BY date DESC"

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        records = cursor.fetchall()

    if not records:
        print("ℹ️ No records found.")
        return

    print(f"\n{'ID':<12} {'Name':<20} {'Date':<15} {'Status':<10}")
    print("-" * 60)
    for row in records:
        print(f"{row[0]:<12} {row[1]:<20} {row[2]:<15} {row[3]:<10}")

def update_record():
    print("\n--- Update Record ---")
    emp_id = input("Enter Student/Employee ID to update: ").strip().upper()
    date_str = input("Enter Date of entry (YYYY-MM-DD): ").strip()

    if not validate_date(date_str):
        print("❌ Invalid date format.")
        return

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT name, status FROM attendance WHERE emp_id = ? AND date = ?", (emp_id, date_str))
        record = cursor.fetchone()

    if not record:
        print("❌ No matching record found.")
        return

    print(f"Current Record: {record[0]} was marked [{record[1]}] on {date_str}.")
    print("Select New Status: [1] Present  [2] Absent  [3] Late")
    choice = input("Enter choice (1-3): ").strip()
    status_map = {"1": "Present", "2": "Absent", "3": "Late"}
    new_status = status_map.get(choice)

    if not new_status:
        print("❌ Invalid choice. Cancelled.")
        return

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE attendance SET status = ? WHERE emp_id = ? AND date = ?",
            (new_status, emp_id, date_str)
        )
        conn.commit()
    
    print("✅ Record updated successfully!")
    sync_db_to_csv()

def generate_report():
    print("\n--- Generate Attendance Report ---")
    emp_id = input("Enter Student/Employee ID: ").strip().upper()

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT name, status FROM attendance WHERE emp_id = ?", (emp_id,))
        records = cursor.fetchall()

    if not records:
        print("❌ No data found for this ID.")
        return

    name = records[0][0]
    total_days = len(records)
    presents = sum(1 for r in records if r[1] == 'Present')
    absents = sum(1 for r in records if r[1] == 'Absent')
    lates = sum(1 for r in records if r[1] == 'Late')
    
    attendance_pct = ((presents + lates) / total_days) * 100 if total_days > 0 else 0

    print(f"\n=======================================")
    print(f"📊 ATTENDANCE REPORT: {name} ({emp_id})")
    print(f"=======================================")
    print(f"Total Tracked Days   : {total_days}")
    print(f"Present              : {presents}")
    print(f"Absent               : {absents}")
    print(f"Late                 : {lates}")
    print(f"Attendance Rate      : {attendance_pct:.2f}%")
    print(f"=======================================")

    export_choice = input("Export report to text file? (y/n): ").strip().lower()
    if export_choice == 'y':
        report_filename = f"{emp_id}_attendance_report.txt"
        with open(report_filename, "w", encoding="utf-8") as f:
            f.write(f"Attendance Report for {name} ({emp_id})\n")
            f.write(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"{'-'*40}\n")
            f.write(f"Total Days: {total_days}\n")
            f.write(f"Present: {presents}\n")
            f.write(f"Absent: {absents}\n")
            f.write(f"Late: {lates}\n")
            f.write(f"Percentage: {attendance_pct:.2f}%\n")
        print(f"💾 Saved to {report_filename}")

def main():
    initialize_db()
    
    while True:
        print("\n=====================================")
        print("    ATTENDANCE MANAGEMENT SYSTEM     ")
        print("=====================================")
        print("1. Mark Attendance")
        print("2. View Records")
        print("3. Update Records")
        print("4. Generate Report")
        print("5. Exit")
        print("=====================================")
        
        choice = input("Select an option (1-5): ").strip()
        
        if choice == "1":
            mark_attendance()
        elif choice == "2":
            view_records()
        elif choice == "3":
            update_record()
        elif choice == "4":
            generate_report()
        elif choice == "5":
            print("\n👋 Exiting system.")
            sys.exit()
        else:
            print("❌ Invalid choice. Try again.")

if __name__ == "__main__":
    main()