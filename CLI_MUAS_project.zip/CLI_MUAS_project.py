import os
import json
import hashlib
class User:
    def __init__(self,Username,Email,Password , role = "user"):
        self.Username = Username
        self.email = Email
        self.password = Password
        self.role = role
    def to_dict(self):
        return{
            'Username': self.Username,
            'email': self.email,
            'password': self.password
        }
class AuthSystem:
    def __init__(self,filename="users.json"):
        self.filename = filename
        self.users = self.load_data()
        #This Function is used to Hash the password
    def HashPassword(self,password):
        return hashlib.sha256(password.encode()).hexdigest()
    # This funcation is used to load data from json file
    def load_data(self):
        if os.path.exists(self.filename):
            try:
                with open(self.filename,'r') as f:
                    data = json.load(f)
                    return([User(u['Username'],u['email'],u['password'])for u in data])
            except (json.JSONDecodeError,TypeError):
                print("Warning : Data Not Found, Starting with empty list")
                return []
        return []
    #This function will save data In json file
    def save_data(self):
        try:
            with open(self.filename, 'w') as f:
                json.dump([u.to_dict() for u in self.users],f,indent = 5)
        except IOError as e:
            print(f"Error to save data: 9 {e}")
    # This funcation will use for validte Email
    def validate_email(self,email):
        if "@" in email and "." in email:
            return True
        return False
    # It will Register the User 
    def register(self):
        Username = input("Enter Username : " ).strip()
        Email = input("Enter Email :").strip()
        Password = input("Enter Password :").strip()
        if not self.validate_email(Email):
            print("Invalid email format")
            return
        if any(u.email == Email for u in self.users):
            print("Email already exists")
            return
        new_user = User(Username,Email,Password=self.HashPassword(Password))
        self.users.append(new_user)
        self.save_data()
        print("User registered successfully.")
    # This is for Login the user
    def login(self):

        Email = input("Enter Email :").strip()
        Password = input("Enter Password :").strip()
        hashed_password = self.HashPassword(Password)
        user = next((u for u in self.users if u.email == Email and u.password == hashed_password), None)
        if user:
            print("Login successful.")
            return user
        else:
            print("Invalid email or password.")
            return None
    # The fuction To rest The password 
    def reset_password(self):
        Email = input("Enter Email :").strip()
        if not self.validate_email(Email):
            print("Invalid email format")
            return
        user = next((u for u in self.users if u.email == Email), None)
        if user:
            new_password = input("Enter New Password :").strip()
            user.password = self.HashPassword(new_password)
            self.save_data()
            print("Password reset successfully.")
        else:
            print("Email not found.")
    def Main_menu(self):
        while True:
            print("1. Register")
            print("2. Login")
            print("3. Reset Password")
            print("4. Exit")
            choice = input("Enter your choice : ").strip()
            match choice:
                case "1":
                    self.register()
                case "2":
                    user = self.login()
                    if user:
                        print(f"Welcome, {user.Username}!")
                    else:
                        print("Login failed.")
                case "3":
                    self.reset_password()
                case "4":
                    print("Exiting...")
                    break
if __name__ == "__main__":
    system = AuthSystem()
    system.Main_menu()