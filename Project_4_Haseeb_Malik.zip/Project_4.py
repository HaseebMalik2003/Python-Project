import re
import os

class LogAnalyzer:
    def __init__(self):
        self.logs = []
        self.file_path = ""
        
        regex_pattern = r'\[(?P<date>.*?)\] (?P<level>INFO|WARNING|ERROR): (?P<message>.*)'
        self.pattern = re.compile(regex_pattern, re.IGNORECASE)

    def load_file(self):
        print("\n--- 📂 File Loading ---")
        path = input("Enter the log filename: ")

        if not os.path.exists(path):
            print(f"⚠️ Sorry, I could not find '{path}'.")
            return False

        self.logs = []
        try:
            with open(path, 'r') as file:
                for line in file:
                    found_match = self.pattern.search(line)
                    if found_match:
                        extracted_data = {
                            "date": found_match.group("date"),
                            "level": found_match.group("level").upper(),
                            "message": found_match.group("message").strip()
                        }
                        self.logs.append(extracted_data)
            
            self.file_path = path
            print(f"✅ Successfully loaded {len(self.logs)} logs.")
            return True
        except Exception as e:
            print(f"❌ Error: {e}")
            return False

    def search_and_filter(self):
        if not self.logs:
            print("⚠️ Load a file first.")
            return

        print("\n--- 🔍 Search Center ---")
        keyword = input("Keyword (optional): ").lower()
        level_needed = input("Level (INFO/WARNING/ERROR): ").upper()

        results = []
        for entry in self.logs:
            match_lvl = (level_needed == "" or entry['level'] == level_needed)
            match_key = (keyword == "" or keyword in entry['message'].lower())

            if match_lvl and match_key:
                results.append(entry)

        print(f"\nResults Found: {len(results)}")
        for r in results:
            print(f"[{r['date']}] {r['level']}: {r['message']}")


class ReportGenerator:
    def __init__(self, data_to_process):
        self.data = data_to_process

    def show_summary(self):
        if not self.data:
            print("⚠️ No data available.")
            return

        counts = {"INFO": 0, "WARNING": 0, "ERROR": 0}
        for entry in self.data:
            lvl = entry['level']
            if lvl in counts:
                counts[lvl] += 1

        print("\n" + "★" * 30)
        print("📊 LOG SUMMARY")
        print("★" * 30)
        print(f"Total Logs: {len(self.data)}")
        for lvl, total in counts.items():
            print(f"• {lvl}: {total}")
        print("★" * 30)


def main_app():
    analyzer = LogAnalyzer()
    
    while True:
        print("\n--- LOG ANALYZER ---")
        print("1. Load File")
        print("2. Search Logs")
        print("3. Show Report")
        print("4. Exit")
        
        choice = input("\nAction: ")

        if choice == '1':
            analyzer.load_file()
        elif choice == '2':
            analyzer.search_and_filter()
        elif choice == '3':
            reporter = ReportGenerator(analyzer.logs)
            reporter.show_summary()
        elif choice == '4':
            print("Goodbye!")
            break
        else:
            print("❌ Invalid choice.")

if __name__ == "__main__":
    main_app()