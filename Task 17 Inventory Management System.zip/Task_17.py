import sqlite3

class InventorySystem:
    def __init__(self):
        self.conn = sqlite3.connect('inventory.db')
        self.cursor = self.conn.cursor()
        self.setup_db()

    def setup_db(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                category TEXT,
                price REAL,
                stock INTEGER
            )
        ''')
        self.conn.commit()

    def add_product(self, name, category, price, stock):
        self.cursor.execute('INSERT INTO products (name, category, price, stock) VALUES (?, ?, ?, ?)',
                           (name, category, price, stock))
        self.conn.commit()

    def update_stock(self, pid, amount):
        self.cursor.execute('UPDATE products SET stock = stock + ? WHERE id = ?', (amount, pid))
        self.conn.commit()

    def get_inventory(self):
        self.cursor.execute('SELECT * FROM products')
        return self.cursor.fetchall()

    def get_low_stock(self(threshold=5)):
        self.cursor.execute('SELECT * FROM products WHERE stock < ?', (threshold,))
        return self.cursor.fetchall()

def main():
    inv = InventorySystem()
    while True:
        print("\n--- INVENTORY MENU ---")
        print("1. Add Product\n2. Update Stock\n3. View Inventory\n4. Low Stock Alert\n5. Exit")
        choice = input("Choice: ")
        
        if choice == '1':
            n = input("Name: ")
            c = input("Category: ")
            p = float(input("Price: "))
            s = int(input("Initial Stock: "))
            inv.add_product(n, c, p, s)
        elif choice == '2':
            pid = int(input("Product ID: "))
            amt = int(input("Change amount (use negative for sales): "))
            inv.update_stock(pid, amt)
        elif choice == '3':
            for row in inv.get_inventory(): print(row)
        elif choice == '4':
            for row in inv.get_low_stock(): print(f"ALERT: {row[1]} is low ({row[4]} left)")
        elif choice == '5':
            break

if __name__ == "__main__":
    main()