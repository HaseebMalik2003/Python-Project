import requests
from bs4 import BeautifulSoup
import json
import csv
import os

class UniversalScraper:
    def __init__(self):
        self.data_store = []
        # Mandatory Requirement: Use Headers to avoid blocking
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }

    def scrape_site(self, category):
        """Fetches data based on the user's category choice."""
        print(f"\n--- Scraping {category} ---")
        
        # Mapping categories to sample URLs
        urls = {
            "News": "https://news.ycombinator.com/",
            "Jobs": "https://remoteok.com/remote-python-jobs",
            "Products": "https://books.toscrape.com/"
        }
        
        target_url = urls.get(category)
        try:
            response = requests.get(target_url, headers=self.headers, timeout=10)
            if response.status_code != 200:
                print(f"❌ Failed to connect to {category} source.")
                return

            soup = BeautifulSoup(response.text, 'html.parser')
            self.data_store = [] # Clear old data

            # Functional Requirement: Extract specific info based on category
            if category == "News":
                items = soup.select('.titleline > a')
                for item in items:
                    self.data_store.append({"Title": item.get_text().strip(), "Link": item['href'], "Category": "News"})
            
            elif category == "Jobs":
                # Logic for a typical job board structure
                jobs = soup.select('.job')
                for job in jobs[:15]: # Limit to 15 for speed
                    title = job.find('h2').get_text().strip() if job.find('h2') else "N/A"
                    company = job.find('h3').get_text().strip() if job.find('h3') else "N/A"
                    self.data_store.append({"Title": title, "Company": company, "Category": "Jobs"})

            elif category == "Products":
                books = soup.select('.product_pod')
                for book in books:
                    title = book.h3.a['title']
                    price = book.select_one('.price_color').get_text()
                    self.data_store.append({"Title": title, "Price": price, "Category": "Products"})

            print(f"✅ Successfully extracted {len(self.data_store)} items.")

        except Exception as e:
            print(f"⚠️ Error occurred: {e}")

    def search_data(self, keyword):
        """Functional Requirement: Search/Filter scraped data"""
        results = [item for item in self.data_store if keyword.lower() in item['Title'].lower()]
        return results

    def save_data(self, file_format):
        """Functional Requirement: Save to CSV or JSON"""
        if not self.data_store:
            print("No data to save!")
            return

        filename = f"scraped_output.{file_format}"
        if file_format == "json":
            with open(filename, 'w') as f:
                json.dump(self.data_store, f, indent=4)
        else:
            keys = self.data_store[0].keys()
            with open(filename, 'w', newline='', encoding='utf-8') as f:
                dict_writer = csv.DictWriter(f, fieldnames=keys)
                dict_writer.writeheader()
                dict_writer.writerows(self.data_store)
        print(f"📂 Data saved as {filename}")

# --- CLI Menu System ---
def menu():
    app = UniversalScraper()
    while True:
        print("\n--- 🛠️ PROFESSIONAL DATA SCRAPER ---")
        print("1. Scrape News")
        print("2. Scrape Jobs")
        print("3. Scrape Products")
        print("4. Search Extracted Data")
        print("5. Save to CSV")
        print("6. Save to JSON")
        print("7. Exit")
        
        choice = input("\nSelect an option: ")

        if choice in ['1', '2', '3']:
            cat = "News" if choice == '1' else "Jobs" if choice == '2' else "Products"
            app.scrape_site(cat)
        elif choice == '4':
            kw = input("Enter keyword: ")
            res = app.search_data(kw)
            for r in res: print(f"-> {r['Title']}")
        elif choice == '5': app.save_data("csv")
        elif choice == '6': app.save_data("json")
        elif choice == '7': break

if __name__ == "__main__":
    menu()