import requests
import feedparser
import json
import csv
from tabulate import tabulate

class NewsArticle:
    def __init__(self, title, source, date, url, category):
        self.title = title
        self.source = source
        self.date = date
        self.url = url
        self.category = category

    def to_dictionary(self):
        return {
            "title": self.title,
            "source": self.source,
            "date": self.date,
            "url": self.url,
            "category": self.category
        }

class NewsManager:
    def __init__(self):
        self.api_key = "YOUR_NEWS_API_KEY"
        self.articles = []
        self.rss_sources = {
            "Technology": "http://feeds.bbci.co.uk/news/technology/rss.xml",
            "Business": "http://feeds.bbci.co.uk/news/business/rss.xml"
        }

    def get_api_news(self, category="general"):
        endpoint = f"https://newsapi.org/v2/top-headlines?category={category}&apiKey={self.api_key}&language=en"
        try:
            response = requests.get(endpoint, timeout=10)
            if response.status_code == 200:
                data = response.json()
                for item in data.get('articles', []):
                    self.articles.append(NewsArticle(
                        item['title'], 
                        item['source']['name'], 
                        item['publishedAt'], 
                        item['url'], 
                        category
                    ))
        except:
            pass

    def get_rss_news(self):
        for category, url in self.rss_sources.items():
            feed = feedparser.parse(url)
            for entry in feed.entries[:5]:
                self.articles.append(NewsArticle(
                    entry.title, "BBC", entry.published, entry.link, category
                ))

    def search(self, term):
        return [a for a in self.articles if term.lower() in a.title.lower()]

    def export(self, file_type):
        if not self.articles:
            return False

        filename = f"news_export.{file_type}"
        data = [a.to_dictionary() for a in self.articles]

        if file_type == 'json':
            with open(filename, 'w') as f:
                json.dump(data, f, indent=4)
        elif file_type == 'csv':
            with open(filename, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=data[0].keys())
                writer.writeheader()
                writer.writerows(data)
        return True

def format_output(news_list):
    if not news_list:
        print("\nNo results to display.")
        return
    
    rows = []
    for i, a in enumerate(news_list):
        rows.append([i + 1, a.source, a.category, a.title[:75]])
    
    headers = ["ID", "Source", "Category", "Headline"]
    print("\n" + tabulate(rows, headers=headers, tablefmt="grid"))

def start():
    manager = NewsManager()
    
    while True:
        print("\n--- News Aggregator System ---")
        print("1. Fetch All Updates")
        print("2. Search by Keyword")
        print("3. Filter by Category")
        print("4. Save to Disk")
        print("5. Exit")
        
        user_input = input("\nAction: ")

        if user_input == '1':
            manager.articles = []
            manager.get_api_news()
            manager.get_rss_news()
            format_output(manager.articles)

        elif user_input == '2':
            term = input("Keyword: ")
            results = manager.search(term)
            format_output(results)

        elif user_input == '3':
            cat = input("Category: ")
            manager.articles = []
            manager.get_api_news(cat)
            format_output(manager.articles)

        elif user_input == '4':
            mode = input("Format (json/csv): ").lower()
            if manager.export(mode):
                print(f"File saved successfully.")

        elif user_input == '5':
            break

if __name__ == "__main__":
    start()