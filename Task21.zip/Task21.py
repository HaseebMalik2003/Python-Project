import sqlite3
from datetime import datetime

class ShopBackend:
    def __init__(self):
        self.db = sqlite3.connect("ecommerce.db")
        self.db.row_factory = sqlite3.Row
        self.setup_tables()
        self.fill_stock()

    def setup_tables(self):
        cursor = self.db.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT,
                price REAL,
                category TEXT,
                quantity INTEGER
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS active_cart (
                product_id INTEGER PRIMARY KEY,
                qty INTEGER
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS orders (
                order_id TEXT,
                summary TEXT,
                total REAL,
                date_str TEXT
            )
        ''')
        self.db.commit()

    def fill_stock(self):
        cursor = self.db.cursor()
        cursor.execute("SELECT COUNT(*) FROM products")
        if cursor.fetchone()[0] == 0:
            items = [
                ("Logitech MX Master 3S Mouse", 99.99, "Electronics", 15),
                ("Keychron K2 Mechanical Keyboard", 79.99, "Electronics", 8),
                ("Anker USB-C Multi-port Hub", 35.50, "Accessories", 25),
                ("Ergonomic Memory Foam Cushion", 45.00, "Office Supply", 5)
            ]
            cursor.executemany("INSERT INTO products (title, price, category, quantity) VALUES (?, ?, ?, ?)", items)
            self.db.commit()

    def display_products(self):
        cursor = self.db.cursor()
        cursor.execute("SELECT * FROM products")
        rows = cursor.fetchall()
        print(f"\n{'ID':<5} {'Product Title':<35} {'Category':<15} {'Price':<10} {'Stock':<5}")
        print("=" * 75)
        for r in rows:
            print(f"{r['id']:<5} {r['title']:<35} {r['category']:<15} ${r['price']:<9.2f} {r['quantity']:<5}")

    def push_to_cart(self, prod_id, qty):
        if qty <= 0: return
        cursor = self.db.cursor()
        cursor.execute("SELECT title, quantity FROM products WHERE id = ?", (prod_id,))
        item = cursor.fetchone()
        
        if not item:
            print("Product ID not recognized.")
            return
            
        cursor.execute("SELECT qty FROM active_cart WHERE product_id = ?", (prod_id,))
        cart_item = cursor.fetchone()
        in_cart = cart_item['qty'] if cart_item else 0
        
        if in_cart + qty > item['quantity']:
            print(f"Insufficient stock. Available: {item['quantity']}. Currently in cart: {in_cart}")
            return

        if in_cart > 0:
            cursor.execute("UPDATE active_cart SET qty = qty + ? WHERE product_id = ?", (qty, prod_id))
        else:
            cursor.execute("INSERT INTO active_cart VALUES (?, ?)", (prod_id, qty))
        self.db.commit()
        print(f"Added {qty} units of '{item['title']}' to cart.")

    def display_cart(self):
        cursor = self.db.cursor()
        cursor.execute('''
            SELECT c.product_id, p.title, p.price, c.qty 
            FROM active_cart c 
            JOIN products p ON c.product_id = p.id
        ''')
        items = cursor.fetchall()
        if not items:
            print("\nYour shopping cart is currently empty.")
            return 0.0

        print(f"\n{'ID':<5} {'Product Title':<35} {'Price':<10} {'Qty':<5} {'Subtotal':<10}")
        print("=" * 70)
        bill = 0.0
        for i in items:
            sub = i['price'] * i['qty']
            bill += sub
            print(f"{i['product_id']:<5} {i['title']:<35} ${i['price']:<9.2f} {i['qty']:<5} ${sub:<10.2f}")
        print(f"Total Invoice Amount: ${bill:.2f}")
        return bill

    def checkout(self):
        cursor = self.db.cursor()
        cursor.execute('''
            SELECT c.product_id, p.title, p.price, c.qty, p.quantity 
            FROM active_cart c 
            JOIN products p ON c.product_id = p.id
        ''')
        items = cursor.fetchall()
        if not items:
            print("Checkout rejected. The cart is empty.")
            return

        for i in items:
            if i['qty'] > i['quantity']:
                print(f"Inventory mismatch on '{i['title']}'. Order canceled.")
                return

        uid = f"ORD-{int(datetime.now().timestamp())}"
        summary = []
        bill = 0.0
        
        for i in items:
            bill += i['price'] * i['qty']
            summary.append(f"{i['title']} (x{i['qty']})")
            cursor.execute("UPDATE products SET quantity = quantity - ? WHERE id = ?", (i['qty'], i['product_id']))
            
        summary_txt = ", ".join(summary)
        now_txt = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        cursor.execute("INSERT INTO orders VALUES (?, ?, ?, ?)", (uid, summary_txt, bill, now_txt))
        cursor.execute("DELETE FROM active_cart")
        self.db.commit()
        
        print("\n=== TRANSACTION SUCCESSFUL ===")
        print(f"Order ID : {uid}")
        print(f"Contents : {summary_txt}")
        print(f"Total    : ${bill:.2f}")

    def display_history(self):
        cursor = self.db.cursor()
        cursor.execute("SELECT * FROM orders ORDER BY date_str DESC")
        logs = cursor.fetchall()
        if not logs:
            print("\nNo localized order history found.")
            return

        print("\n--- TRANSACTION HISTORY LOGS ---")
        for l in logs:
            print(f"ID: {l['order_id']} | Date: {l['date_str']}")
            print(f"  Summary: {l['summary']}")
            print(f"  Charged: ${l['total']:.2f}")
            print("-" * 60)

    def close_connection(self):
        self.db.close()

def main():
    store = ShopBackend()
    while True:
        print("\n=== BACKEND MARKET INTERFACE ===")
        print("1. Browse Items")
        print("2. Add to Cart")
        print("3. View Cart")
        print("4. Pay & Checkout")
        print("5. Order History")
        print("6. Exit")
        
        opt = input("Choice: ").strip()
        if opt == "1":
            store.display_products()
        elif opt == "2":
            try:
                p_id = int(input("Target Product ID: "))
                count = int(input("Target Quantity: "))
                store.push_to_cart(p_id, count)
            except ValueError:
                print("Error: Input must be structural numeric digits.")
        elif opt == "3":
            store.display_cart()
        elif opt == "4":
            store.checkout()
        elif opt == "5":
            store.display_history()
        elif opt == "6":
            store.close_connection()
            break

if __name__ == "__main__":
    main()