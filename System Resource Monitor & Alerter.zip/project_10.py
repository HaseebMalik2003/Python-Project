import psutil
import time
import csv
import os
from datetime import datetime
from plyer import notification  # Install with: pip install plyer

class SystemMonitor:
    def __init__(self):
        self.thresholds = {'cpu': 80.0, 'ram': 80.0, 'disk': 90.0}
        self.log_file = "system_logs.csv"
        self._init_log()

    def _init_log(self):
        """Initialize the CSV file with headers if it doesn't exist."""
        if not os.path.exists(self.log_file):
            with open(self.log_file, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(["Timestamp", "CPU (%)", "RAM (%)", "Disk (%)"])

    def set_thresholds(self):
        print("\n--- Set Alert Thresholds ---")
        try:
            self.thresholds['cpu'] = float(input("Enter CPU Threshold % (default 80): ") or 80)
            self.thresholds['ram'] = float(input("Enter RAM Threshold % (default 80): ") or 80)
            self.thresholds['disk'] = float(input("Enter Disk Threshold % (default 90): ") or 90)
            print("✅ Thresholds updated!")
        except ValueError:
            print("❌ Invalid input. Keeping previous values.")

    def log_data(self, cpu, ram, disk):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(self.log_file, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([timestamp, cpu, ram, disk])

    def check_alerts(self, cpu, ram, disk):
        alerts = []
        if cpu > self.thresholds['cpu']: alerts.append(f"CPU at {cpu}%")
        if ram > self.thresholds['ram']: alerts.append(f"RAM at {ram}%")
        if disk > self.thresholds['disk']: alerts.append(f"Disk at {disk}%")
        
        for msg in alerts:
            print(f"⚠️  ALERT: {msg}")
            notification.notify(title="System Alert", message=msg, timeout=2)

    def start_monitoring(self, interval=2):
        print(f"\nMonitoring started (Interval: {interval}s). Press Ctrl+C to stop.")
        print(f"{'Timestamp':<20} | {'CPU%':<6} | {'RAM%':<6} | {'Disk%':<6}")
        print("-" * 50)
        
        try:
            while True:
                cpu = psutil.cpu_percent(interval=None)
                ram = psutil.virtual_memory().percent
                disk = psutil.disk_usage('/').percent
                ts = datetime.now().strftime("%H:%M:%S")

                print(f"{ts:<20} | {cpu:<6} | {ram:<6} | {disk:<6}")
                
                self.log_data(cpu, ram, disk)
                self.check_alerts(cpu, ram, disk)
                
                time.sleep(interval)
        except KeyboardInterrupt:
            print("\nStopped monitoring.")

def main_menu():
    monitor = SystemMonitor()
    while True:
        print("\n--- 🖥️  System Resource Monitor ---")
        print("1. Start Real-Time Monitoring")
        print("2. Set Alert Thresholds")
        print("3. View Log File Path")
        print("4. Exit")
        
        choice = input("\nSelect an option: ")
        
        if choice == '1':
            monitor.start_monitoring()
        elif choice == '2':
            monitor.set_thresholds()
        elif choice == '3':
            print(f"\nLogs are being saved to: {os.path.abspath(monitor.log_file)}")
        elif choice == '4':
            break
        else:
            print("Invalid choice, try again.")

if __name__ == "__main__":
    main_menu()