import os
import shutil
import csv
from datetime import datetime
class File_renamer:
    def __init__(self , directory):
        self.directory = directory
        if not os.path.exists(self.directory):
            raise FileNotFoundError(f"Directory{self.directory} not found.")
        
    def File_renaming(self , prefix = "" , sufix = "" , find = "", replace = "" , auto_num = False):
        files = [f for f in os.listdir(self.directory)if os.path.isfile(os.path.join(self.directory, f))]
        logs = []
        for i , filename in enumerate(files , 1):
            name , ext = os.path.splitext(filename)
            #Logic for renaming a file 
            new_name = name.replace(find, replace)if find else name
            new_name = f"{prefix}{new_name}{sufix}"
            if auto_num:
                new_name+= f"_{i}"
            new_name +=ext
            old_path = os.path.join(self.directory, filename)
            new_path = os.path.join(self.directory,new_name)

            #Prevent from overwriting the File
            if not os.path.exists(new_path):
                os.rename(old_path , new_path)
                logs.append([datetime.now().strftime("%y -%m - %d - %h - %t - %s"), filename , new_name])
            else:
                print(f"Skipped :{new_name} already exist ")
        self.Logging_System(logs)
    def File_organizing(self):
        files = [f for f in os.listdir(self.directory)if os.path.isfile(os.path.join(self.directory,f))]
        logs = []
        for filename in files:
            ext = filename.split('.')[-1].lower()if '.' in filename else 'no extension'
            target_directory = os.path.join(self.directory , ext)

            os.makedirs(target_directory , exist_ok=True)


            shutil.move(os.path.join(self.directory,filename),os.path.join(target_directory, filename))
            logs.append([datetime.now().strftime("%Y-%m-%d %H:%M:%S"), filename, f"{ext}/", "Moved"])
            
            self.Logging_System(logs)
            print(f"Sucessfuly organized {len(files)}files")
    def Preview_System(self, prefix = '' , sufix = '' , find = '' , replace = '', auto_num = False):

        files = [f for f in os.listdir(self.directory)if os.path.isfile(os.path.join(self.directory , f))]
        print(f"Privew")
        for i , filename in enumerate(files, 1):
            name , ext = os.path.splitext(filename)
            new_name = name.replace(find , replace)if find else name
            new_name = f"{prefix}{new_name}{sufix}"
            if auto_num:
                new_name += f"_{i}"
            print(f"{filename} --- {new_name}{ext}")
    
    def Logging_System(self, logentries):
        with open("Operation_log.csv","a",newline="")as f:
            writter = csv.writer(f)
            writter.writerows(logentries)
        
def menu():
    path = input("Enter a path please ")
    bot = File_renamer(path)
    while True:
        print(f" \n1. File Reanming\n 2. File Oragnizing \n 3. preview \n 4. Logging \n Exit")
        try:
            choice = int(input("Enter your choise : "))
        except ValueError as e:
            print(f"Error{e}")
        match choice:
            case 1:
                pre = input("Prefix")
                suf = input("Sufix")
                find = input("Find to Replace word")
                rep = input("Replace with")
                num = input("auto number y/n ").lower() == 'y'
                bot.File_renaming(pre , suf , find , rep , num)
                print("Renaming completed")
            case 2:
                bot.File_organizing()
            case 3:
                pre = input(f"Prefix: ")
                suf = input(f"Sufix: ")
                bot.Preview_System(prefix = pre , sufix= suf)
            case 4:
                if os.path.exists("Operation_log.csv"):
                    with open("Operation_log.csv","r")as f:
                        print(f"\n Recents Logs")
                        print(f.read())

                else:
                    print(f"No logs found ")
            case 5:
                print("Exiting ")
                break
            case _:
                print("Invalid choice ")
if __name__ == "__main__":
    menu()