import requests
import json
from datetime import datetime
import os

# --- Configuration ---
# Get your free key at https://www.exchangerate-api.com/
API_KEY = "YOUR_API_KEY_HERE" 
BASE_URL = f"https://v6.exchangerate-api.com/v6/{API_KEY}/latest/"
HISTORY_FILE = "conversion_history.json"

class CurrencyConverter:
    def __init__(self):
        self.history = self.load_history()

    def get_exchange_rate(self, base_currency):
        """Fetches live exchange rates for a base currency."""
        try:
            response = requests.get(f"{BASE_URL}{base_currency.upper()}")
            response.raise_for_status()
            data = response.json()
            
            if data.get("result") == "success":
                return data["conversion_rates"]
            else:
                print(f"❌ API Error: {data.get('error-type')}")
        except requests.exceptions.ConnectionError:
            print("❌ Error: No internet connection.")
        except Exception as e:
            print(f"❌ Error fetching rates: {e}")
        return None

    def convert(self, amount, from_curr, to_curr):
        """Performs the conversion and returns a record."""
        rates = self.get_exchange_rate(from_curr)
        if rates and to_curr.upper() in rates:
            rate = rates[to_curr.upper()]
            converted_amount = amount * rate
            
            record = {
                "from": from_curr.upper(),
                "to": to_curr.upper(),
                "amount": amount,
                "result": round(converted_amount, 2),
                "rate": rate,
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            return record
        else:
            print(f"❌ Error: Currency code '{to_curr}' not supported.")
            return None

    def save_history(self, record):
        """Appends conversion record to JSON file."""
        self.history.append(record)
        with open(HISTORY_FILE, "w") as f:
            json.dump(self.history, f, indent=4)
        print("✅ Conversion saved to history.")

    def load_history(self):
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, "r") as f:
                return json.load(f)
        return []

    def display_history(self):
        if not self.history:
            print("\n📜 No conversion history found.")
            return
        print("\n--- 🕒 Recent Conversions ---")
        for h in self.history[-10:]:  # Show last 10
            print(f"[{h['timestamp']}] {h['amount']} {h['from']} ➡️  {h['result']} {h['to']} (Rate: {h['rate']})")

def main():
    converter = CurrencyConverter()
    
    while True:
        print("\n--- 💸 Real-Time Currency Converter ---")
        print("1. Convert Currency")
        print("2. View Exchange Rates (Quick Check)")
        print("3. View Conversion History")
        print("4. Exit")
        
        choice = input("Select an option: ")

        if choice == '1':
            try:
                base = input("From Currency (e.g., USD): ").strip()
                target = input("To Currency (e.g., PKR): ").strip()
                amount = float(input("Amount to convert: "))
                
                result = converter.convert(amount, base, target)
                if result:
                    print(f"\n💰 Result: {amount} {result['from']} = {result['result']} {result['to']}")
                    converter.save_history(result)
            except ValueError:
                print("❌ Invalid amount. Please enter a number.")

        elif choice == '2':
            base = input("Enter Base Currency: ").strip()
            rates = converter.get_exchange_rate(base)
            if rates:
                print(f"\n--- Popular Rates for 1 {base.upper()} ---")
                for c in ['USD', 'PKR', 'EUR', 'GBP', 'SAR']:
                    if c in rates:
                        print(f"{c}: {rates[c]}")

        elif choice == '3':
            converter.display_history()

        elif choice == '4':
            print("👋 Goodbye!")
            break

if __name__ == "__main__":
    main()