import requests
import json
import time
from datetime import datetime
from tabulate import tabulate

class CryptoTracker:
    def __init__(self):
        self.api_url = "https://api.coingecko.com/api/v3/simple/price"
        self.history_file = "price_history.json"
        self.monitored_coins = ["bitcoin", "ethereum", "binancecoin", "solana", "cardano"]

    def fetch_live_data(self, coin_ids=None):
        """Fetches real-time data from CoinGecko API."""
        ids = ",".join(coin_ids) if coin_ids else ",".join(self.monitored_coins)
        params = {
            "ids": ids,
            "vs_currencies": "usd",
            "include_market_cap": "true",
            "include_24hr_change": "true"
        }
        
        try:
            response = requests.get(self.api_url, params=params, timeout=10)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"\n[!] Connection Error: Could not fetch data. {e}")
            return None

    def save_to_history(self, data):
        """Appends current session data to a JSON file with timestamps."""
        history = []
        try:
            with open(self.history_file, "r") as f:
                history = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            pass

        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        for coin, info in data.items():
            history.append({
                "coin": coin.capitalize(),
                "price": f"${info['usd']:,}",
                "24h_change": f"{info['usd_24h_change']:.2f}%",
                "timestamp": timestamp
            })

        with open(self.history_file, "w") as f:
            json.dump(history, f, indent=4)

    def display_dashboard(self, data):
        """Formats the API response into a clean CLI table."""
        if not data:
            return

        table_data = []
        for coin, info in data.items():
            table_data.append([
                coin.capitalize(),
                f"${info['usd']:,}",
                f"{info['usd_24h_change']:.2f}%",
                f"${int(info['usd_market_cap']):,}"
            ])

        headers = ["Coin", "Price (USD)", "24h Change", "Market Cap"]
        print("\n" + tabulate(table_data, headers=headers, tablefmt="fancy_grid"))

    def show_history(self):
        """Reads and displays saved history."""
        try:
            with open(self.history_file, "r") as f:
                history = json.load(f)
                if not history:
                    print("\nNo history recorded yet.")
                    return
                
                # Show last 10 entries
                recent = history[-10:]
                print("\n--- Recent Price History ---")
                print(tabulate(recent, headers="keys", tablefmt="presto"))
        except FileNotFoundError:
            print("\n[!] No data file found. Save some data first!")

    def run(self):
        """Main Menu System."""
        while True:
            print("\n--- 🪙 CRYPTO TRACKER PRO ---")
            print("1. View Live Prices")
            print("2. Search Specific Coin")
            print("3. View Price History")
            print("4. Exit")
            
            choice = input("\nSelect an option (1-4): ")

            if choice == "1":
                data = self.fetch_live_data()
                if data:
                    self.display_dashboard(data)
                    self.save_to_history(data)
            elif choice == "2":
                coin_name = input("Enter coin name (e.g., dogecoin): ").lower().strip()
                data = self.fetch_live_data([coin_name])
                if data:
                    self.display_dashboard(data)
            elif choice == "3":
                self.show_history()
            elif choice == "4":
                print("Exiting... Happy Trading!")
                break
            else:
                print("Invalid choice, please try again.")

if __name__ == "__main__":
    tracker = CryptoTracker()
    tracker.run()