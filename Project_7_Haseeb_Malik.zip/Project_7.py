import pandas as pd
import os
from tabulate import tabulate
class Datatool:
    def __init__(self):
        self.df = None
        self.filename = ""
    def Load_file(self):
        path = input("Enter a path of your file : ")
        try:
            self.df = pd.read_excel(path)
            self.filename = os.basename(path)
            print(f"Data is loaded Sucessfull {self.filename}")
        except Exception as error:
            print(f"Error{error}")
    def Clean_data(self):
        if self.df is None:
            print("Load a file first ")
        intial_count = len(self.df)

        self.df.drop_duplicates(inplace=True)
        self.df.columns = self.df.columns.str.strip().str.lower().str.replace(' ','_')
        
        print("Missing vaule Stratagey \n " \
        "1 Fill with Mean" \
        "\n2 Drop Row \n" \
        "3 Fill with N/A")
        choice = int(input("Enter a Choice 1 , 2 , 3"))
        if choice == 1:
            num_cols = self.df.select_dtypes(include=['number']).columns
            self.df[num_cols] = self.df[num_cols].fillna(self.df[num_cols].mean())
        elif choice == 2:
            self.df.dropna(inplace=True)
        else:
            self.df.fillna("N/A", inplace=True)
    def Analyze_data(self):
        if self.df is None:
            return print("Load file first")
        print("\n Data summery")
        print(f"Data Records {len(self.df)}")
        print(f"Colums {list(self.df.columns)}")
            
        print(f"\n Statasical Anaylisis ")
        stats = self.df.describe()
        print(tabulate(stats, header = 'keys',tablefmt = 'psql'))

        col = input("Enter colums to group by or press Enter to Skip")
        if col in self.df.columns:
            grouoped = self.df.groupby(col).size().rest_index(name = 'count')
            print(tabulate(grouoped, header =' keys' , tablefmt = 'psql'))

    def Filter_data(self):
        if self.df is None:
            print("Enter The data file first")
        col = input("Enter  column to filer").strip().lower()
        if col in self.df.column:
            value = input("Search vaule in {col}: ").strip()
            mask = self.df[col].astype(str).str.contain(value , case = False , na = False)
            result = self.df[mask]
            print(tabulate(result.head(10), header = 'key' , tablefmt = 'psql'))
        else:
            print(f"Column not found")
    def Save_Data(self):
        if self.df is None : return print(f"Load file First ")
        outputname = f"cleaned_{self.filename}"
        self.df.to_excel(outputname , index = False)

        with open(f"Summar_report.txt", "w") as f:
            f.write(f"Report for {self.filename}\n")
            f.write(f"Total Rows : {len(self.df)}\n")
            f.write(f"Columns : {' , '.join(self.df.columns)}\n")
        print(f"Saved as {outputname} and summary_report.txt")
def main_menu():
    tool = Datatool()
    menu = {
            "1": tool.Load_file,
            "2": tool.Clean_data,
            "3": tool.Analyze_data,
            "4": tool.Filter_data,
            "5": tool.Save_Data,
            "6": exit
        }
    while True:
        print(f"\n --Excel Data Tool--")
        print(f" 1. Load File \n 2. Clean Data \n 3. Analyze Data \n 4.Filter data \n 5. Save data \n 6. exit ")
        choice = input("Select an option : ")
        action = menu.get(choice)
        if action:
            action()
        else:
            print("Invalid option")
if __name__ == "__main__":
    main_menu()