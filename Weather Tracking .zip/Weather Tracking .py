import requests
import json
import csv
from datetime import datetime
import os

# --- Configuration ---
API_KEY = "YOUR_OPENWEATHER_API_KEY"  # Replace with your API Key
BASE_URL = "https://api.openweathermap.org/data/2.5/weather"
HISTORY_FILE = "weather_history.json"

class WeatherDashboard:
    def __init__(self):
        self.history = self.load_history()

    def fetch_weather(self, city):
        """Fetches live weather data from OpenWeatherMap API."""
        params = {
            "q": city,
            "appid": API_KEY,
            "units": "metric"  # For Celsius
        }
        try:
            response = requests.get(BASE_URL, params=params)
            response.raise_for_status() # Raises error for 404, 500, etc.
            return response.json()
        except requests.exceptions.HTTPError:
            print(f"❌ Error: City '{city}' not found.")
        except requests.exceptions.ConnectionError:
            print("❌ Error: No internet connection.")
        except Exception as e:
            print(f"❌ An unexpected error occurred: {e}")
        return None

    def display_weather(self, data):
        """Prints formatted weather details to CLI."""
        city = data['name']
        temp = data['main']['temp']
        humidity = data['main']['humidity']
        condition = data['weather'][0]['description']
        wind = data['wind']['speed']

        print(f"\n--- Current Weather in {city} ---")
        print(f"🌡️  Temperature: {temp}°C")
        print(f"☁️  Condition: {condition.capitalize()}")
        print(f"💧 Humidity: {humidity}%")
        print(f"💨 Wind Speed: {wind} m/s")
        
        return {
            "city": city,
            "temp": temp,
            "condition": condition,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

    def save_to_history(self, record):
        """Saves a single weather record to the local JSON list."""
        self.history.append(record)
        try:
            with open(HISTORY_FILE, "w") as f:
                json.dump(self.history, f, indent=4)
            print("✅ Data saved to history.")
        except Exception as e:
            print(f"❌ Failed to save data: {e}")

    def load_history(self):
        """Loads history from JSON file if it exists."""
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, "r") as f:
                return json.load(f)
        return []

    def view_history(self):
        """Displays all stored weather records."""
        if not self.history:
            print("\n📂 No history recorded yet.")
            return
        
        print("\n--- Weather History ---")
        for idx, entry in enumerate(self.history, 1):
            print(f"{idx}. [{entry['timestamp']}] {entry['city']}: {entry['temp']}°C, {entry['condition']}")

    def analyze_trends(self):
        """Simple analysis: Average temperature of stored history."""
        if not self.history:
            print("\n📂 No data to analyze.")
            return
        
        temps = [entry['temp'] for entry in self.history]
        avg_temp = sum(temps) / len(temps)
        print(f"\n--- Data Analysis ---")
        print(f"📊 Total Records: {len(self.history)}")
        print(f"🌡️  Average Recorded Temp: {avg_temp:.20}°C")
        print(f"📈 Max Temp: {max(temps)}°C | 📉 Min Temp: {min(temps)}°C")

def main_menu():
    dashboard = WeatherDashboard()
    
    while True:
        print("\n--- 🌦️  Weather Dashboard Menu ---")
        print("1. Get Weather")
        print("2. View History")
        print("3. Analyze Data")
        print("4. Exit")
        
        choice = input("Select an option (1-4): ")

        if choice == '1':
            city = input("Enter city name: ").strip()
            data = dashboard.fetch_weather(city)
            if data:
                record = dashboard.display_weather(data)
                save_opt = input("Save this to history? (y/n): ").lower()
                if save_opt == 'y':
                    dashboard.save_to_history(record)
        
        elif choice == '2':
            dashboard.view_history()
            
        elif choice == '3':
            dashboard.analyze_trends()
            
        elif choice == '4':
            print("👋 Exiting... Stay weather-wise!")
            break
        else:
            print("❌ Invalid choice. Please try again.")

if __name__ == "__main__":
    main_menu()